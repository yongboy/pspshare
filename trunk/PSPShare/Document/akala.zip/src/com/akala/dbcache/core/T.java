package com.akala.dbcache.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class T {

	public static void main(String[] args) {

		// l.clear();
		// b=null;
		MyThread mt = new MyThread();
		mt.start();
		// System.gc();

		// try {
		// Thread.sleep(3000);
		// } catch (InterruptedException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }
		//
		// System.gc();
		//		
		// try {
		// Thread.sleep(3000);
		// } catch (InterruptedException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }
		System.out.println("aaaaaaaaaaaaaaaa");
	}
}

class B {
	public void finalize() {
		System.out.println("gc...");
	}
}

class MyThread extends Thread {
	Map cache = new HashMap();

	static int ticker = 0;

	public MyThread() {
		ArrayList l = new ArrayList();
		B b = new B();
		l.add(b);
		cache.put("cache_one", l);
	}

	public void run() {

		while (true) {
			try {
				ticker++;
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (ticker > 3)
				cache.remove("cache_one");

			System.gc();
			System.out.println("tick:" + ticker);
		}
	}
}
